package kbc;
import org.json.simple.parser.JSONParser;
import org.json.simple.*;
import java.util.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*; 
import java.lang.*;
import java.awt.*;
import java.util.*;
import java.applet.*;
import java.awt.event.*;
import java.util.Timer;
import java.util.TimerTask; 
import java.lang.*;
import java.io.*;
//import sun.audio.*;
import java.awt.*;
import java.util.*;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import java.util.Properties;    
import javax.mail.*;    
import javax.mail.internet.*; 
import javax.sound.sampled.AudioInputStream; 
import javax.sound.sampled.AudioSystem; 
import javax.sound.sampled.Clip; 
import javax.sound.sampled.LineUnavailableException; 
import javax.sound.sampled.UnsupportedAudioFileException; 
class greet implements ActionListener
{
		JFrame jf=new JFrame();
		String n,e;
		JTextField a = new JTextField();
		JTextField b = new JTextField();
		JFrame frm=new JFrame("WELCOME FRAME");
		greet()
		{
			JLabel name = new JLabel("ENTER YOUR NAME",JLabel.CENTER);
			JLabel email = new JLabel("ENTER YOUR EMAIL",JLabel.CENTER);
			ImageIcon image2 = new ImageIcon("kbc1.png");
			Font myfont=new Font("serif",Font.BOLD,30);
			ImageIcon image = new ImageIcon("start-button-10.jpg");
			JButton jb=new JButton("START");
			JLabel symbol = new JLabel("", image2, JLabel.CENTER);
			a.setHorizontalAlignment(JTextField.CENTER);
			b.setHorizontalAlignment(JTextField.CENTER);
			frm.setLayout(null);
			jb.setIcon(image);
			jb.setBounds(150,350,660,240);
			frm.add(jb);
			a.setBounds(50,80,900,50);
			a.setFont(myfont);
			frm.add(a);
			b.setBounds(50,210,900,50);
			b.setFont(myfont);
			frm.add(b);
			symbol.setBounds(50,650,900,220);
			frm.add(symbol);
			name.setFont(myfont);
			name.setBounds(0,20,1000,50);
			frm.add(name);
			email.setFont(myfont);
			email.setBounds(0,150,1000,50);
			frm.add(email);
			frm.setSize(1000,1000);
			frm.setVisible(true);
			jb.addActionListener(this);
			b.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e1) {
				boolean flag;
				n=a.getText();
				e=b.getText();
				flag=e.contains("@gmail.com");
				if(a.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null, "NAME CAN NOT BE LEFT NULL");
				}
				else if(b.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null, "EMAIL CAN NOT BE LEFT NULL");
				}
				else if(flag!=true)
				{
					b.setText("");
					JOptionPane.showMessageDialog(null, "IMPROPER EMAIL ADRESS");
				}
				else
				{
					frm.setVisible(false);
					new_kbc jframe=new new_kbc();
					jframe.setBackground(Color.black);
					jframe.setPreferredSize(new Dimension(1980, 1320));
					jframe.setVisible(true);
					jframe.n(get());
					jframe.e(gete());
					jf.add(jframe);
					jf.setVisible(true);
					jf.setSize(1980,1320);
				}

			}

			});
			a.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e1) {
				boolean flag;
				n=a.getText();
				e=b.getText();
				flag=e.contains("@gmail.com");
				if(a.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null, "NAME CAN NOT BE LEFT NULL");
				}
				else if(b.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null, "EMAIL CAN NOT BE LEFT NULL");
				}
				else if(flag!=true)
				{
					b.setText("");
					JOptionPane.showMessageDialog(null, "IMPROPER EMAIL ADRESS");
				}
				else
				{
					frm.setVisible(false);
					new_kbc jframe=new new_kbc();
					jframe.setBackground(Color.black);
					jframe.setPreferredSize(new Dimension(1980, 1320));
					jframe.setVisible(true);
					jframe.n(get());
					jframe.e(gete());
					jf.add(jframe);
					jf.setVisible(true);
					jf.setSize(1980,1320);
				}

			}

			});
		}
		public void actionPerformed(ActionEvent ae)
		{
				boolean flag;
				n=a.getText();
				e=b.getText();
				flag=e.contains("@gmail.com");
				if(a.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null, "NAME CAN NOT BE LEFT NULL");
				}
				else if(b.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null, "EMAIL CAN NOT BE LEFT NULL");
				}
				else if(flag!=true)
				{
					b.setText("");
					JOptionPane.showMessageDialog(null, "IMPROPER EMAIL ADRESS");
				}
				else 
				{
					frm.setVisible(false);
					new_kbc jframe=new new_kbc();
					jframe.setBackground(Color.black);
					jframe.setPreferredSize(new Dimension(1980, 1320));
					jframe.setVisible(true);
					jframe.n(get());
					jframe.e(gete());
					jf.add(jframe);
					jf.setVisible(true);
					jf.setSize(1980,1320);
				}
		}
		public String get()
		{
			return n;
		}
		public String gete()
		{
			return e;
		}
}
class Mailer{  
    public static void send(final String from,final String password,String to,String sub,String msg){  
          //Get properties object    
          Properties props = new Properties();    
          props.put("mail.smtp.host", "smtp.gmail.com");    
          props.put("mail.smtp.socketFactory.port", "465");    
          props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");    
          props.put("mail.smtp.auth", "true");    
          props.put("mail.smtp.port", "465");    
          //get Session   
          Session session = Session.getDefaultInstance(props,new javax.mail.Authenticator() {    
           protected PasswordAuthentication getPasswordAuthentication() {    
           return new PasswordAuthentication(from,password);  
           }    
          });    
          //compose message    
          try {    
           MimeMessage message = new MimeMessage(session);    
           message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));    
           message.setSubject(sub);    
           message.setText(msg);    
           //send message  
           Transport.send(message);        
          } catch (MessagingException e) {

			  throw new RuntimeException(e);
          }    
             
    }  
} 
public class new_kbc extends JPanel implements ActionListener,MouseListener,MouseMotionListener
{
	int i=-1;
	int ll=0;
	String name,mailer;
	public void paintComponent( Graphics g ) {
					Color customColor = new Color(60,30,96);
                    super.paintComponent(g);
                    Graphics2D g2 = (Graphics2D)g;
                    Line2D line = new Line2D.Double(1320,280,1920,280);
                    g2.setColor(customColor);
                    g2.setStroke(new BasicStroke(3));
                    g2.draw(line);
                    line = new Line2D.Double(1320,0,1320,1080);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(70,550,1250,550);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(70,680,1250,680);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(0,615,70,550);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(0,615,70,680);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(1320,615,1250,550);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(1320,615,1250,680);
                    g2.setColor(customColor);
                    g2.draw(line);
                    //************************************
                    line = new Line2D.Double(70,700,600,700);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(720,700,1250,700);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(70,900,600,900);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(720,900,1250,900);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(70,800,600,800);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(720,800,1250,800);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(0,850,70,800);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(0,850,70,900);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(0,750,70,700);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(0,750,70,800);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(1320,850,1250,800);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(1320,850,1250,900);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(1320,750,1250,700);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(1320,750,1250,800);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(660,750,720,700);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(660,750,720,800);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(660,850,720,800);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(660,850,720,900);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(660,750,600,700);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(660,750,600,800);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(660,850,600,800);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(660,850,600,900);
                    g2.setColor(customColor);
                    g2.draw(line);
                    line = new Line2D.Double(1320,100,1980,100);
                    g2.setColor(customColor);
                    g2.draw(line);
                 }
	public class ProgressBarExample {
	int a,b,c,d;
	final JFrame frame = new JFrame("AUDIENCE");
 public void rand(String ans)
 {
	 int max=100;
	 if(ans.equals("a"))
	{
		max=100;
		 Random r=new Random();
		 a=r.nextInt(60)+1;
		 max=max-a;
		 b=r.nextInt(max)+1;
		 max=max-b;
		 c=r.nextInt(max)+1;
		 d=100-a-b-c;
	}
	else if(ans.equals("b"))
	{
		max=100;
		 Random r=new Random();
		 b=r.nextInt(60)+1;
		 max=max-b;
		 a=r.nextInt(max)+1;
		 max=max-a;
		 d=r.nextInt(max)+1;
		 c=100-a-b-d;
	}
	else if(ans.equals("c"))
	{
		 Random r=new Random();
		 c=r.nextInt(60)+1;
		 max=max-c;
		 a=r.nextInt(max)+1;
		 max=max-a;
		 d=r.nextInt(max)+1;
		 b=100-a-d-c;
	}
	else if(ans.equals("d"))
	 {
		 Random r=new Random();
		 d=r.nextInt(60)+1;
		 max=max-d;
		 b=r.nextInt(max)+1;
		 max=max-b;
		 c=r.nextInt(max)+1;
		 a=100-d-b-c;
	}
 }
    public void status(String ans)
    {
		
        final int MAX = 100;
        final JProgressBar pb = new JProgressBar();
        pb.setMinimum(0);
        pb.setMaximum(MAX);
        pb.setStringPainted(true);
        frame.setLayout(new FlowLayout());
        frame.getContentPane().add(pb);
		final JProgressBar pb2 = new JProgressBar();
        pb2.setMinimum(0);
        pb2.setMaximum(MAX);
        pb2.setStringPainted(true);
        frame.setLayout(new FlowLayout());
        frame.getContentPane().add(pb2);
        final JProgressBar pb3 = new JProgressBar();
        pb3.setMinimum(0);
        pb3.setMaximum(MAX);
        pb3.setStringPainted(true);
        frame.setLayout(new FlowLayout());
        frame.getContentPane().add(pb3);
        final JProgressBar pb4 = new JProgressBar();
        pb4.setMinimum(0);
        pb4.setMaximum(MAX);
        pb4.setStringPainted(true);
        frame.setLayout(new FlowLayout());
        frame.getContentPane().add(pb4);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300,300);
        frame.setVisible(true);
        rand(ans);
        for (int i = 0; i <= a; i++) {
            final int currentValue = i;
            try {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        pb.setValue(currentValue);
                    }
                });
                java.lang.Thread.sleep(30);
            } catch (InterruptedException e) {
                JOptionPane.showMessageDialog(frame, e.getMessage());
            }
        }
		
         for (int i = 0; i <= b; i++) {
            final int currentValue = i;
            try {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        pb2.setValue(currentValue);
                    }
                });
                java.lang.Thread.sleep(30);
            } catch (InterruptedException e) {
                JOptionPane.showMessageDialog(frame, e.getMessage());
            }
        }
        for (int i = 0; i <= c; i++) {
            final int currentValue = i;
            try {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        pb3.setValue(currentValue);
                    }
                });
                java.lang.Thread.sleep(30);
            } catch (InterruptedException e) {
                JOptionPane.showMessageDialog(frame, e.getMessage());
            }
        }
        for (int i = 0; i <= d; i++) {
            final int currentValue = i;
            try {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        pb4.setValue(currentValue);
                    }
                });
                java.lang.Thread.sleep(30);
            } catch (InterruptedException e) {
                JOptionPane.showMessageDialog(frame, e.getMessage());
            }
        }
    }
}

	class thread extends Thread
	{
		int flag=0;
		int timer=30;
		String l;
		public void run()
		{
			for(int i=0;i<=300;i++)
			{
					try
					{
						l=Integer.toString(timer);
						s.setText(l);
						timer--;
						Thread.sleep(1000);
					}catch(Exception e)
					{
					};
					if(timer<=0)
					{
						quit();
					}
			}
		}
		public void stopt()
		{
			timer=348924;
		}
	}
	public void n(String s)
	{
		name=s;
	}
	public void e(String s)
	{
		mailer=s;
	}
	public class sound
	{
//		AudioStream audioStream;
		Clip clip;
		public void getkbc()
		{
				try
				 {
					String gongFile = "kbc.wav";
					InputStream in = new FileInputStream(gongFile);
					AudioInputStream audioInputStream; 
					audioInputStream =  AudioSystem.getAudioInputStream(new File(gongFile).getAbsoluteFile()); 
					clip = AudioSystem.getClip(); 
			        clip.open(audioInputStream);  
				}catch(Exception e)
				{
				};
			}
			public void getright()
			{
				try
				  {
					String gongFile = "right.wav";
					InputStream in = new FileInputStream(gongFile);
//					audioStream = new AudioStream(in); 
					AudioInputStream audioInputStream; 
					audioInputStream =  AudioSystem.getAudioInputStream(new File(gongFile).getAbsoluteFile()); 
					clip = AudioSystem.getClip(); 
			        clip.open(audioInputStream);  
				}catch(Exception e)
				{
				};
			}
			public void getwrong()
			{
				try
				  {
					String gongFile = "wrong.wav";
					InputStream in = new FileInputStream(gongFile);
//					audioStream = new AudioStream(in); 
					AudioInputStream audioInputStream; 
					audioInputStream =  AudioSystem.getAudioInputStream(new File(gongFile).getAbsoluteFile()); 
					clip = AudioSystem.getClip(); 
			        clip.open(audioInputStream);  
				}catch(Exception e)
				{
				};
			}
			public void gettic()
			{
				try
				  {
					String gongFile = "tic.wav";
					InputStream in = new FileInputStream(gongFile);
//					audioStream = new AudioStream(in); 
					AudioInputStream audioInputStream; 
					audioInputStream =  AudioSystem.getAudioInputStream(new File(gongFile).getAbsoluteFile()); 
					clip = AudioSystem.getClip(); 
			        clip.open(audioInputStream);  
				}catch(Exception e)
				{
				};
			}
			public  void playkbc()
			{
				getkbc();
				clip.start();
//				 AudioPlayer.player.start(audioStream);
			}
			public  void playtic()
			{
				gettic();
				clip.start();
//				 AudioPlayer.player.start(audioStream);
			}
			public  void playright()
			{
				getright();
				clip.start();
//				AudioPlayer.player.start(audioStream);
			}
			public  void playwrong()
			{
				getwrong();
				clip.start();
//				AudioPlayer.player.start(audioStream);
			}
			public  void stopkbc()
			{
		        clip.stop(); 
		        clip.close();
//				 AudioPlayer.player.stop(audioStream);
			}
			public  void stopright()
			{
				 clip.stop(); 
			        clip.close();
//				AudioPlayer.player.stop(audioStream);
			}
			public  void stopwrong()
			{
				 clip.stop(); 
			        clip.close();
//				AudioPlayer.player.stop(audioStream);
			}
			public  void stoptic()
			{
				 clip.stop(); 
			        clip.close();
//				AudioPlayer.player.stop(audioStream);
			}
	}
	class disp
	{
		String ans,que,op1,op2,op3,op4;
		public String[] getdata(int c)
		{
			String a[]=new String[10];
			JSONParser parser = new JSONParser();
			String que="";
			try 
			{
				Object obj = parser.parse(new FileReader("db.json"));
				JSONObject jsonObject = (JSONObject) obj;
				int i=0;
				JSONArray cells = (JSONArray) jsonObject.get("items");
				Iterator<JSONObject> iterator = cells.iterator();
				while(iterator.hasNext() && i<c)
				{
					JSONObject jsonObject2 = (JSONObject) iterator.next();
					a[0]=(String)jsonObject2.get("que");
					a[1]=(String)jsonObject2.get("op1");
					a[2]=(String)jsonObject2.get("op2");
					a[3]=(String)jsonObject2.get("op3");
					a[4]=(String)jsonObject2.get("op4");
					a[5]=(String)jsonObject2.get("ans");
				   i++;
				 }

     } 
     catch (Exception e)
     {
		e.printStackTrace();
	}
			return a;
		}
	}
	sound s3=new sound();
	int t=1,flag=0;
	disp d1=new disp();
	Color c1 = new Color(5,154,28);
	JFrame jf=new JFrame("cheque");
	JButton next,e,q,ff,qf;
	JLabel l2,o1,o2,o3,o4,s,icon,q1,q2,q3,q4,q5,q6,q7,q8,q9,q10,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,inf;
	JButton jb=new JButton("replay");
	ImageIcon image = new ImageIcon("kbc1.png");
	ImageIcon dd = new ImageIcon("ap.png");
	ImageIcon f = new ImageIcon("ff.png");
	ImageIcon fnf = new ImageIcon("ffn.png");
	ImageIcon qnf = new ImageIcon("anp.png");
	JLabel symbol = new JLabel("", image, JLabel.CENTER);
	String que="who is the pm of America?";
	String op1="Modi";
	String op2="Sonia gandhi";
	String op3="Navaj sharif";
	String op4="Obama";
	String ans="d";
	String cash="0";
	String cashw="zero";
	Color customColor = new Color(155,155,155);
	thread t3=new thread();
	new_kbc()
	{
		setBackground(Color.black);
		setLayout(null);
		Font myfont=new Font("serif",Font.BOLD,30);
		Font myfont1=new Font("serif",Font.BOLD,15);
		l2=new JLabel(que,JLabel.CENTER);
		l2.setBounds(70,565,1180,100);
		l2.setFont(myfont);
		l2.setForeground(Color.white);
		add(l2);
		//inf.setBounds(1320,30,600,100);
		ff=new JButton();
		ff.setIcon(f);
		qf=new JButton();
		qf.setIcon(dd);
		next=new JButton("Next");
		q=new JButton("Quit");
		ff.setBounds(1700,150,83,87);
		add(ff);
		qf.setBounds(1500,150,83,83);
		add(qf);
		setFont(new Font("serif", Font.BOLD, 15));
		next.setBackground(Color.black);
		next.setForeground(Color.white);
		next.setBounds(1153,950,100,25);
		add(next);
		q.setBackground(Color.black);
		q.setForeground(Color.white);
		q.setBounds(72,950,100,25);
		add(q);
		o1=new JLabel(op1,JLabel.CENTER);
		o1.setBounds(68,700,532,100);
		o1.setFont(myfont);
		o1.setForeground(Color.white);
		add(o1);
		o2=new JLabel(op2,JLabel.CENTER);
		o2.setBounds(720,700,532,100);
		o2.setFont(myfont);
		o2.setForeground(Color.white);
		add(o2);
		o3=new JLabel(op3,JLabel.CENTER);
		setLayout(null);
		o3.setBounds(68,800,532,100);
		o3.setFont(myfont);
		o3.setForeground(Color.white);
		add(o3);
		o4=new JLabel(op4,JLabel.CENTER);
		o4.setBounds(720,800,532,100);
		o4.setFont(myfont);
		o4.setForeground(Color.white);
		add(o4);
		symbol.setBounds(511,120,300,300);
		add(symbol);
		s=new JLabel("",JLabel.CENTER);
		setLayout(null);
		s.setBounds(0,750,1320,100);
		s.setFont(myfont);
		s.setForeground(Color.white);
		add(s);
		inf=new JLabel("   Life Line",JLabel.CENTER);
		setLayout(null);
		inf.setBounds(1320,0,600,100);
		inf.setFont(myfont);
		inf.setForeground(Color.orange);
		add(inf);
		q1=new JLabel("5,000",JLabel.RIGHT);
		setLayout(null);
		q1.setBounds(1520,920,300,30);
		q1.setFont(myfont);
		q1.setForeground(Color.orange);
		add(q1);
		q2=new JLabel("20,000",JLabel.RIGHT);
		setLayout(null);
		q2.setBounds(1520,850,300,30);
		q2.setFont(myfont);
		q2.setForeground(Color.white);
		add(q2);
		q3=new JLabel("80,000",JLabel.RIGHT);
		setLayout(null);
		q3.setBounds(1520,790,300,30);
		q3.setFont(myfont);
		q3.setForeground(Color.white);
		add(q3);
		q4=new JLabel("3,20,000",JLabel.RIGHT);
		setLayout(null);
		q4.setBounds(1520,720,300,30);
		q4.setFont(myfont);
		q4.setForeground(Color.orange);
		add(q4);
		q5=new JLabel("12,50,000",JLabel.RIGHT);
		setLayout(null);
		q5.setBounds(1520,650,300,30);
		q5.setFont(myfont);
		q5.setForeground(Color.white);
		add(q5);
		q6=new JLabel("25,00,000",JLabel.RIGHT);
		setLayout(null);
		q6.setBounds(1520,570,300,30);
		q6.setFont(myfont);
		q6.setForeground(Color.white);
		add(q6);
		q7=new JLabel("50,00,000",JLabel.RIGHT);
		setLayout(null);
		q7.setBounds(1520,500,300,30);
		q7.setFont(myfont);
		q7.setForeground(Color.orange);
		add(q7);
		q8=new JLabel("1 Crore",JLabel.RIGHT);
		setLayout(null);
		q8.setBounds(1520,430,300,30);
		q8.setFont(myfont);
		q8.setForeground(Color.white);
		add(q8);
		q9=new JLabel("5 Crore",JLabel.RIGHT);
		setLayout(null);
		q9.setBounds(1520,370,300,30);
		q9.setFont(myfont);
		q9.setForeground(Color.white);
		add(q9);
		q10=new JLabel("7 Crore",JLabel.RIGHT);
		setLayout(null);
		q10.setBounds(1520,320,300,30);
		q10.setFont(myfont);
		q10.setForeground(Color.orange);
		add(q10);
		i1=new JLabel("1.",JLabel.LEFT);
		setLayout(null);
		i1.setBounds(1420,920,300,30);
		i1.setFont(myfont);
		i1.setForeground(Color.orange);
		add(i1);
		i2=new JLabel("2.",JLabel.LEFT);
		setLayout(null);
		i2.setBounds(1420,850,300,30);
		i2.setFont(myfont);
		i2.setForeground(Color.white);
		add(i2);
		i3=new JLabel("3.",JLabel.LEFT);
		setLayout(null);
		i3.setBounds(1420,790,300,30);
		i3.setFont(myfont);
		i3.setForeground(Color.white);
		add(i3);
		i4=new JLabel("4.",JLabel.LEFT);
		setLayout(null);
		i4.setBounds(1420,720,300,30);
		i4.setFont(myfont);
		i4.setForeground(Color.orange);
		add(i4);
		i5=new JLabel("5.",JLabel.LEFT);
		setLayout(null);
		i5.setBounds(1420,650,300,30);
		i5.setFont(myfont);
		i5.setForeground(Color.white);
		add(i5);
		i6=new JLabel("6.",JLabel.LEFT);
		setLayout(null);
		i6.setBounds(1420,570,300,30);
		i6.setFont(myfont);
		i6.setForeground(Color.white);
		add(i6);
		i7=new JLabel("7.",JLabel.LEFT);
		setLayout(null);
		i7.setBounds(1420,500,300,30);
		i7.setFont(myfont);
		i7.setForeground(Color.orange);
		add(i7);
		i8=new JLabel("8.",JLabel.LEFT);
		setLayout(null);
		i8.setBounds(1420,430,300,30);
		i8.setFont(myfont);
		i8.setForeground(Color.white);
		add(i8);
		i9=new JLabel("9.",JLabel.LEFT);
		setLayout(null);
		i9.setBounds(1420,370,300,30);
		i9.setFont(myfont);
		i9.setForeground(Color.white);
		add(i9);
		i10=new JLabel("10.",JLabel.LEFT);
		setLayout(null);
		i10.setBounds(1420,320,300,30);
		i10.setFont(myfont);
		i10.setForeground(Color.orange);
		add(i10);
		next.addActionListener(this);
		q.addActionListener(this);
		ff.addActionListener(this);
		qf.addActionListener(this);
		addMouseListener(this); 
		addMouseMotionListener(this); 
		setque();
	}
	public void remove()
	{
		removeMouseListener(this);
		removeMouseMotionListener(this); 
	}
	public void add()
	{
		addMouseListener(this);
		addMouseMotionListener(this); 
	}
	public void quit()
	{
		t3.timer=30000;
		Calendar now = Calendar.getInstance();
         int month = now.get(Calendar.MONTH)+1;
         int day = now.get(Calendar.DAY_OF_MONTH);
          int year = now.get(Calendar.YEAR);
          String date=""+day+"/"+month+"/"+year;
		this.setVisible(false);
		add(jb);
		jb.addActionListener(this);
		Font myfont=new Font("serif",Font.BOLD,30);
		Font myfont1=new Font("Comic Sans MS",Font.BOLD,40);
		Font myfont2=new Font("Comic Sans MS",Font.BOLD,30);
		JLabel namec=new JLabel(name);
		JLabel thanks=new JLabel("CONGRATULATION",JLabel.CENTER);
		JLabel amc=new JLabel(cash);
		JLabel amcw=new JLabel(cashw);
		JLabel d=new JLabel(date);
		namec.setFont(myfont);
		amc.setFont(myfont);
		amcw.setFont(myfont);
		d.setFont(myfont);
		jf.setLayout(null);
		thanks.setBounds(0,0,1350,70);
		namec.setBounds(95,115,1000,100);
		amcw.setBounds(105,175,1000,100);
		amc.setBounds(950,235,1000,100);
		d.setBounds(1020,50,1000,100);
		thanks.setFont(myfont1);
		jb.setFont(myfont2);
		jb.setBackground(Color.lightGray);
		jb.setForeground(Color.black);
		jb.setBounds(575,585,200,50);
		jf.setContentPane(new JLabel(new ImageIcon("che.jpg")));
		 jf.add(thanks); 
		 jf.add(amcw);
		 jf.add(namec);
		 jf.add(amc);
		 jf.add(d);
		 jf.add(jb);
		 jf.setSize(1350,700);
		 jf.setVisible(true);
		 Mailer.send("teamkbc007@gmail.com","kbc123456789",mailer,"Greetings from kbc team","Dear Participant("+name+") thanks for taking part in Kaun Banega Crorepati(KBC) and We would like to congratulate you for wining "+cashw+"("+cash+") price money.");
	}
	public void setque()
	{
			i++;
			t=i;
			q.setVisible(true);
			next.removeActionListener(this);
			Random rand = new Random();
			t = rand.nextInt(18) + 1;
			disp d1=new disp();
			String[] a =d1.getdata(t);
			l2.setText(a[0]);
			o1.setForeground(Color.white);
			o2.setForeground(Color.white);
			o3.setForeground(Color.white);
			o4.setForeground(Color.white);
			o1.setText(a[1]);
			o2.setText(a[2]);
			o3.setText(a[3]);
			o4.setText(a[4]);
			ans=a[5];
			if(i==1)
			{
				cash="5,000";
				cashw="Five Thousand Rupee";
				i1.setForeground(customColor);
				q1.setForeground(customColor);
			}
			else if(i==2)
			{
				i2.setForeground(customColor);
				q2.setForeground(customColor);
			}
			else if(i==3)
			{
				i3.setForeground(customColor);
				q3.setForeground(customColor);
			}
			else if(i==4)
			{
				cashw="Three Lakh Twnety Thousand Rupee";
				cash="3,20,000";
				i4.setForeground(customColor);
				q4.setForeground(customColor);
			}
			else if(i==5)
			{
				i5.setForeground(customColor);
				q5.setForeground(customColor);
			}
			else if(i==6)
			{
				i6.setForeground(customColor);
				q6.setForeground(customColor);
			}
			else if(i==7)
			{
				cash="50,00,000";
				cashw="Fifty Lakh Rupee";
				i7.setForeground(customColor);
				q7.setForeground(customColor);
			}
			else if(i==8)
			{
				i8.setForeground(customColor);
				q8.setForeground(customColor);
			}
			else if(i==9)
			{
				i9.setForeground(customColor);
				q9.setForeground(customColor);
			}
			else if(i==10)
			{
				cashw="Seven Crore Rupee";
				cash="7 crore";
				s3.playkbc();
				i10.setForeground(customColor);
				q10.setForeground(customColor);
				quit();
			}
			
			if(i<4)
			{
				s3.playtic();
				t3.timer=30;
				s.setVisible(true);
				t3.start();
				
			}
			else
			{
				t3.stopt();
			}
			
	}
	public void mouseDragged(MouseEvent e) {  
} 
	public void mouseClicked(MouseEvent e) {  
       String a1="";
       int x=e.getX();
       int y=e.getY();
       if((x>68 && x<600) && (y>800 && y<900))
       {
		   a1="c";
	   }
	   if((x>68 && x<600) && (y>700 && y<800))
       {
		   a1="a";
	   }
	   if((x>721 && x<1251) && (y>700 && y<800))
       {
		   a1="b";
	   }
	   if((x>721 && x<1251) && (y>800 && y<900))
       {
		   a1="d";
	   }
	   if(a1.equals(ans) && ((x>68 && x<600) && (y>800 && y<900) || (x>68 && x<600) && (y>700 && y<800) || (x>721 && x<1251) && (y>700 && y<800) || (x>721 && x<1251) && (y>800 && y<900)))
		{
			t3.timer=300000;
			if(ll==1)
			{
				qf.addActionListener(this);
				ll=0;
			}
			s3.stopkbc();
			q.removeActionListener(this);
			s3.stoptic();
			s.setVisible(false);
			s3.playright();
			remove();
			next.addActionListener(this);
			if(a1.equals("a"))
			{
				o1.setForeground(c1);
			}
			else if(a1.equals("b"))
			{
				o2.setForeground(c1);
			}
			else if(a1.equals("c"))
			{
				o3.setForeground(c1);
			}
			else
			{
				o4.setForeground(c1);
			}
		}
		else if(((x>68 && x<600) && (y>800 && y<900) || (x>68 && x<600) && (y>700 && y<800) || (x>721 && x<1251) && (y>700 && y<800) || (x>721 && x<1251) && (y>800 && y<900)))
		{
			qf.removeActionListener(this);
			ff.removeActionListener(this);
			s3.stopkbc();
			s3.stoptic();
			s.setVisible(false);
			q.setVisible(false);
			s3.playwrong();
			if(a1.equals("a"))
			{ 
				o1.setForeground(Color.red);
			}
			else if(a1.equals("b"))
			{ 
				o2.setForeground(Color.red);
			}
			else if(a1.equals("c"))
			{ 
				o3.setForeground(Color.red);
			}
			else if(a1.equals("d"))
			{ 
				o4.setForeground(Color.red);
			}
			if(ans.equals("a"))
			{ 
				o1.setForeground(c1);
			}
			else if(ans.equals("b"))
			{ 
				o2.setForeground(c1);
			}
			else if(ans.equals("c"))
			{ 
				o3.setForeground(c1);
			}
			else if(ans.equals("d"))
			{ 
				o4.setForeground(c1);
			}
			remove();
			next.setText("Exit");
			next.addActionListener(this);
			
		}
    }  
    public void mouseMoved(MouseEvent e) {  
		 int x=e.getX();
       int y=e.getY();
       if((x>68 && x<600) && (y>700 && y<800))
       {
		   o1.setForeground(Color.orange);
		   o2.setForeground(Color.white);
		   o3.setForeground(Color.white);
		   o4.setForeground(Color.white);
	   }
	   else if((x>721 && x<1251) && (y>700 && y<800))
       {
		    o2.setForeground(Color.orange);
		    o1.setForeground(Color.white);
		    o3.setForeground(Color.white);
		    o4.setForeground(Color.white);
	   }
	   else if((x>68 && x<600) && (y>800 && y<900))
       {
		    o3.setForeground(Color.orange);
		    o1.setForeground(Color.white);
		    o2.setForeground(Color.white);
		    o4.setForeground(Color.white);
	   }
	   else if((x>721 && x<1251) && (y>800 && y<900))
       { 
		    o4.setForeground(Color.orange);
		    o1.setForeground(Color.white);
		    o2.setForeground(Color.white);
		    o3.setForeground(Color.white);
	   }
	   else 
	   {
		    o4.setForeground(Color.white);
		    o1.setForeground(Color.white);
		    o2.setForeground(Color.white);
		    o3.setForeground(Color.white);
	   }
	} 
    public void mouseEntered(MouseEvent e)
     {  
    }  
    public void mouseExited(MouseEvent e) {  
    }  
    public void mousePressed(MouseEvent e) {  
    }  
    public void mouseReleased(MouseEvent e) {  
    }  
	public void actionPerformed(ActionEvent ae)
	{
		String a1;
		a1=ae.getActionCommand();
		if(ae.getSource()==qf)
		{
			qf.setIcon(qnf);
			ProgressBarExample p=new ProgressBarExample();
			p.status(ans);
			qf.removeActionListener(this);
		}
		else if(ae.getSource()==ff)
		{
			ll=1;
			q.setVisible(false);
			qf.removeActionListener(this);
			next.removeActionListener(this);
			q.removeActionListener(this);
			ff.setIcon(fnf);
			ff.removeActionListener(this);
			if(ans.equals("a"))
			{
				o2.setText("");
				o3.setText("");
			}
			if(ans.equals("b"))
			{
				o1.setText("");
				o3.setText("");
			}
			if(ans.equals("c"))
			{
				o1.setText("");
				o4.setText("");
			}
			if(ans.equals("d"))
			{
				o1.setText("");
				o2.setText("");
			}
		}
		else if(a1.equals("replay"))
		{
			jf.setVisible(false);
			new greet();
		}
		else if(a1.equals("Quit"))
		{
			if(i==1)
			{
				cashw="Five Thousand Rupee";
				cash="5,000";
			}
			if(i==2)
			{
				cashw="Twenty Thousand Rupee";
				cash="20,000";
			}
			if(i==3)
			{
				cashw="Eighty Thousand Rupee";
				cash="80,000";
			}
			if(i==4)
			{
				cashw="Three Lakh Twnety Thousand Rupee";
				cash="3,20,000";
			}
			if(i==5)
			{
				cashw="Twelve Lakh Fifty Thousand Rupee";
				cash="12,50,000";
			}
			if(i==6)
			{
				cashw="Fifty Lakh Rupee";
				cash="50,00,000";
			}
			if(i==7)
			{
				cashw="One Crore Rupee";
				cash="1 Crore";
			}
			if(i==8)
			{
				cashw="Five Crore Rupee";
				cash="5 Crore";
			}
			if(i==9)
			{
				cashw="Seven Crore Rupee";
				cash="7 Crore";
			}
			s3.stoptic();
			quit();
		}
		else if(a1.equals("Next"))
		{
			if(i>=10)
			{
				quit();
			}
			else
			{
				q.addActionListener(this);
				s3.stopright();
				add();
				setque();
			}
			
		}
		else if(a1.equals("Exit"))
		{
			s3.stopwrong();
			quit();
		}
	}
	public static void main(String args[])	
	{
		new greet();
	}
}
